import React, { useEffect } from 'react';

export default function App() {
  useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('visible');
          obs.unobserve(e.target);
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.fade-in').forEach(el => obs.observe(el));

    const handleSmoothScroll = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a');
      if (anchor && anchor.getAttribute('href')?.startsWith('#')) {
        e.preventDefault();
        const id = anchor.getAttribute('href');
        if (id) {
          const element = document.querySelector(id);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        }
      }
    };

    document.addEventListener('click', handleSmoothScroll);

    return () => {
      obs.disconnect();
      document.removeEventListener('click', handleSmoothScroll);
    };
  }, []);

  return (
    <>
      <nav>
        <a className="nav-logo" href="#">
          <div className="nav-logo-icon">
            <span style={{ background: '#4285F4' }}></span>
            <span style={{ background: '#E91E8C' }}></span>
            <span style={{ background: '#F9AB00' }}></span>
            <span style={{ background: '#34A853' }}></span>
          </div>
          PS-Style GAN
        </a>
        <ul className="nav-links">
          <li><a href="#abstract">Abstract</a></li>
          <li><a href="#methodology">Methodology</a></li>
          <li><a href="#algorithm">Algorithm</a></li>
          <li><a href="#results">Results</a></li>
          <li><a href="#references">References</a></li>
          <li><a href="https://github.com" target="_blank" rel="noreferrer" className="nav-cta">View on GitHub →</a></li>
        </ul>
      </nav>

      <div className="hero">
        <div className="hero-circles">
          <div className="c c1"></div>
          <div className="c c2"></div>
          <div className="c c3"></div>
          <div className="c c4"></div>
        </div>
        <div className="hero-content">
          <div className="hero-tag">
            <span className="dot"></span>
            SRM Institute of Science and Technology · Chennai, India
          </div>
          <h1>
            <span className="word-ps">PS</span><span className="word-style">-Style</span> <span className="word-gan">GAN</span><br />Sketch Generator
          </h1>
          <p className="hero-subtitle">Hyper-realistic facial sketch generation using a hybrid PS-Style GAN and CV2 model — preserving identity while delivering artistic beauty.</p>

          <div className="hero-authors">
            <div className="author-chip">
              <div className="author-avatar" style={{ background: '#4285F4' }}>AK</div>
              <div>
                <div className="author-name">Ajay Kumar Reddy K</div>
                <div className="author-role">Lead · Designer</div>
              </div>
            </div>
            <div className="author-chip">
              <div className="author-avatar" style={{ background: '#E91E8C' }}>SR</div>
              <div>
                <div className="author-name">Sameer Raja E</div>
                <div className="author-role">CSE · SRM</div>
              </div>
            </div>
            <div className="author-chip">
              <div className="author-avatar" style={{ background: '#F9AB00' }}>JF</div>
              <div>
                <div className="author-name">Jesheba Fedorah E</div>
                <div className="author-role">CSE · SRM</div>
              </div>
            </div>
            <div className="author-chip">
              <div className="author-avatar" style={{ background: '#34A853' }}>TV</div>
              <div>
                <div className="author-name">Thanvarshini VR</div>
                <div className="author-role">CSE · SRM</div>
              </div>
            </div>
          </div>

          <div className="hero-cta-row">
            <a href="https://github.com" target="_blank" rel="noreferrer" className="btn-primary">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" /></svg>
              View on GitHub
            </a>
            <a href="#abstract" className="btn-secondary">Read the Paper ↓</a>
          </div>

          <div className="keyword-pills" style={{ justifyContent: 'center', marginTop: '40px' }}>
            <span className="pill">StyleGAN</span>
            <span className="pill">Face Sketch Generation</span>
            <span className="pill">GANs</span>
            <span className="pill">Computer Vision</span>
            <span className="pill">Image Processing</span>
            <span className="pill">Facial Entertainment</span>
          </div>
        </div>
      </div>

      <div className="full-bleed" id="abstract">
        <div className="abstract-block fade-in">
          <div className="section-label">Abstract</div>
          <h2 className="section-title" style={{ textAlign: 'center' }}>The Problem &amp; The Solution</h2>
          <blockquote>
            Most modern filters take too long and produce results with little resemblance to the original face. PS-Style GAN fixes this — combining a CV2 Hybrid Model with controlled noise injection to extract facial features, preserve identity, and generate high-quality sketches fast.
          </blockquote>
          <p style={{ marginTop: '28px', fontSize: '16px', color: 'var(--muted)', lineHeight: 1.75, textAlign: 'left' }}>
            In light of the recent growth of AI-powered face filters, facial entertainment has seen a significant spike in user engagement. The basic problem identified in most modern filters is that they generate sketches with <strong>high latency</strong> and <strong>low identity preservation</strong>. To tackle this, we use PS Style GAN and CV2 Hybrid Model which produces better quality images with high resemblance in a shorter period of time. Prominent filters use Gaussian and Inverse Filtering — but PS-Style GAN uses noise injection and CV2 to retain originality. Applications include social media, animation, digital art, personalized merchandise, and a face morphing feature that blends two people's faces.
          </p>
        </div>
      </div>

      <section id="methodology">
        <div className="fade-in">
          <div className="section-label">Methodology</div>
          <div className="two-col">
            <div>
              <h2 className="section-title">How the system works</h2>
              <p className="section-body">
                The framework integrates classical computer vision techniques with deep generative modeling — transforming facial photographs into stylized pencil sketches while preserving structural identity.
              </p>
            </div>
            <div>
              <p style={{ fontSize: '15px', color: 'var(--muted)', lineHeight: 1.8 }}>
                The hybrid approach combines deterministic edge-based features from OpenCV with semantic facial embeddings learned using a deep generative network. The result is a sketch that's both <em>geometrically accurate</em> and <em>artistically expressive</em>.
              </p>
            </div>
          </div>

          <div className="pipeline-grid">
            <div className="pipeline-step">
              <div className="step-num" style={{ color: '#4285F4' }}>01</div>
              <div className="step-title">Image Input &amp; Preprocessing</div>
              <div className="step-desc">User uploads a face. Image is resized to 256×256, normalized, and optionally augmented with flips, rotations, and brightness shifts.</div>
            </div>
            <div className="pipeline-step">
              <div className="step-num" style={{ color: '#E91E8C' }}>02</div>
              <div className="step-title">Landmark Detection</div>
              <div className="step-desc">68 facial landmarks detected using dlib. 9 hair points + 16 boundary points added = 93 control points per image for precise warping.</div>
            </div>
            <div className="pipeline-step">
              <div className="step-num" style={{ color: '#F9AB00' }}>03</div>
              <div className="step-title">Face Morphing</div>
              <div className="step-desc">Delaunay triangulation + affine warp blends two faces. Midpoint mesh computed by pm = (1−α)pts1 + α·pts2 for smooth identity interpolation.</div>
            </div>
            <div className="pipeline-step">
              <div className="step-num" style={{ color: '#34A853' }}>04</div>
              <div className="step-title">Classical Sketch (CV2)</div>
              <div className="step-desc">Grayscale conversion → Gaussian blur → dodge division produces the base pencil sketch, capturing edges, jawline, eyes, nose, and lips.</div>
            </div>
            <div className="pipeline-step">
              <div className="step-num" style={{ color: '#EA4335' }}>05</div>
              <div className="step-title">PS-Style GAN Refinement</div>
              <div className="step-desc">VGG19 encoder extracts deep features. Decoder with skip connections generates refined sketch over 5 progressive iterations of increasing fidelity.</div>
            </div>
            <div className="pipeline-step">
              <div className="step-num" style={{ color: '#FF6D00' }}>06</div>
              <div className="step-title">Hybrid Fusion &amp; Output</div>
              <div className="step-desc">Final sketch: S = GAN × β + CV2 × (1−β). Combines structural clarity of classical CV2 with artistic refinement of the GAN.</div>
            </div>
          </div>
        </div>
      </section>

      <div className="full-bleed">
        <div style={{ maxWidth: '1200px', margin: '0 auto' }} className="fade-in">
          <div className="section-label">Key Innovations</div>
          <h2 className="section-title">What makes PS-Style GAN different</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon" style={{ background: '#E8F0FE' }}>🎯</div>
              <h3>Identity Preservation</h3>
              <p>Unlike traditional Gaussian-based filters that lose facial features, PS-Style GAN extracts and retains prominent identity markers — eyes, symmetry, jawline — throughout generation.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon" style={{ background: '#FCE8F0' }}>⚡</div>
              <h3>Faster Generation</h3>
              <p>The hybrid CV2 + GAN pipeline produces high-quality sketches in a fraction of the time compared to diffusion-based alternatives — making it viable for real-time entertainment apps.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon" style={{ background: '#E6F4EA' }}>🧬</div>
              <h3>Face Morphing</h3>
              <p>Interpolate between two facial identities in latent space. The morphing pipeline produces smooth, coherent blends using Delaunay triangulation and 93-point control meshes.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon" style={{ background: '#FEF7E0' }}>🎨</div>
              <h3>Controlled Noise Injection</h3>
              <p>Instead of random noise, structured noise injection preserves identity features and prevents distortion — resulting in sketches that look artistic yet recognizable.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon" style={{ background: '#FCE8E6' }}>🔗</div>
              <h3>Skip-Connection Decoder</h3>
              <p>The GAN decoder uses skip connections from the VGG19 encoder, retaining multi-scale spatial information for fine-grained structural accuracy in the output sketch.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon" style={{ background: '#E8F0FE' }}>🌐</div>
              <h3>Broad Applications</h3>
              <p>Social media filters, digital art, animation, personalized merchandise, gaming avatars, and AR/VR — the system is designed to integrate across the entertainment stack.</p>
            </div>
          </div>
        </div>
      </div>

      <section id="algorithm">
        <div className="fade-in">
          <div className="section-label">Algorithm</div>
          <h2 className="section-title">The full pipeline in pseudocode</h2>
          <p className="section-body">End-to-end algorithm from raw face images to final hybrid neural sketch.</p>
          <div className="algo-block">
            <pre>
<span className="algo-cmt">{`// PS-Style GAN · Hybrid Facial Sketch Algorithm
// Input: Face images I1, I2 · Morph factor α · Blend weight β
// Output: Final neural sketch S`}</span>

<span className="algo-kw">Step 1</span>: <span className="algo-fn">Preprocessing</span>
  Resize I1, I2 → <span className="algo-num">256</span>×<span className="algo-num">256</span>
  Normalize pixel values to <span className="algo-str">[0, 1]</span>

<span className="algo-kw">Step 2</span>: <span className="algo-fn">Landmark Detection</span>
  Detect <span className="algo-num">68</span> facial landmarks using dlib
  Apply upsampling if face detection fails

<span className="algo-kw">Step 3</span>: <span className="algo-fn">Anchor Point Generation</span>
  Add <span className="algo-num">9</span> hair points + <span className="algo-num">16</span> boundary points
  Total control points = <span className="algo-num">93</span> per image

<span className="algo-kw">Step 4</span>: <span className="algo-fn">Face Morphing</span>
  pm = (<span className="algo-num">1</span> − α) · pts1 + α · pts2
  Delaunay triangulation → affine warp → blend → morphed face M

<span className="algo-kw">Step 5</span>: <span className="algo-fn">Classical Sketch (CV2)</span>
  M → grayscale → Gaussian blur → dodge division → edge sharpening

<span className="algo-kw">Step 6</span>: <span className="algo-fn">GAN-Based Refinement</span>
  Extract features via frozen VGG19 encoder
  Decode with skip connections → GAN sketch

<span className="algo-kw">Step 7</span>: <span className="algo-fn">Hybrid Fusion</span>
  S = GAN × β + CV2 × (<span className="algo-num">1</span> − β)

<span className="algo-kw">return</span> Final sketch image S
            </pre>
          </div>
        </div>
      </section>

      <section id="results">
        <div className="fade-in">
          <div className="section-label">Results</div>
          <h2 className="section-title">Experimental observations</h2>
          <p className="section-body">Evaluated across multiple facial inputs for quality, identity preservation, and morphing coherence.</p>

          <div className="results-grid">
            <div className="result-card">
              <div className="result-img-placeholder">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#888" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15l-5-5L5 21" /></svg>
                Add your image in /public/morph.png
              </div>
              <div className="result-caption">
                Face Morphing Output
                <div className="result-sub">93-point Delaunay triangulation blend</div>
              </div>
            </div>
            <div className="result-card">
              <div className="result-img-placeholder">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#888" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15l-5-5L5 21" /></svg>
                Add your image in /public/cv2sketch.png
              </div>
              <div className="result-caption">
                Classical CV2 Sketch
                <div className="result-sub">Gaussian blur + dodge division baseline</div>
              </div>
            </div>
            <div className="result-card">
              <div className="result-img-placeholder">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#888" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15l-5-5L5 21" /></svg>
                Add your image in /public/gansketch.png
              </div>
              <div className="result-caption">
                PS-Style GAN Hybrid Output
                <div className="result-sub">Final fused result: S = GAN×β + CV2×(1−β)</div>
              </div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '16px', marginTop: '40px' }}>
            <div style={{ background: 'var(--surface)', borderRadius: '16px', padding: '28px', textAlign: 'center', border: '1px solid var(--border)' }}>
              <div style={{ fontSize: '42px', fontWeight: 700, fontFamily: 'var(--font-display)', color: '#4285F4' }}>93</div>
              <div style={{ fontSize: '13px', color: 'var(--muted)', marginTop: '4px' }}>Control Points per Face</div>
            </div>
            <div style={{ background: 'var(--surface)', borderRadius: '16px', padding: '28px', textAlign: 'center', border: '1px solid var(--border)' }}>
              <div style={{ fontSize: '42px', fontWeight: 700, fontFamily: 'var(--font-display)', color: '#E91E8C' }}>5</div>
              <div style={{ fontSize: '13px', color: 'var(--muted)', marginTop: '4px' }}>Progressive GAN Iterations</div>
            </div>
            <div style={{ background: 'var(--surface)', borderRadius: '16px', padding: '28px', textAlign: 'center', border: '1px solid var(--border)' }}>
              <div style={{ fontSize: '42px', fontWeight: 700, fontFamily: 'var(--font-display)', color: '#34A853' }}>2×</div>
              <div style={{ fontSize: '13px', color: 'var(--muted)', marginTop: '4px' }}>Faster than Diffusion Models</div>
            </div>
          </div>
        </div>
      </section>

      <div className="full-bleed" id="references">
        <div style={{ maxWidth: '1200px', margin: '0 auto' }} className="fade-in">
          <div className="section-label">References</div>
          <h2 className="section-title">Related work</h2>
          <div className="ref-list">
            <div className="ref-item"><span className="ref-num">[6]</span><span>Jain, K. K., J, A. V., &amp; Namboodiri, A. (2024). <strong>PS-StyleGAN: Illustrative portrait sketching using attention-based style adaptation.</strong> arXiv. — The primary inspiration for this work.</span></div>
            <div className="ref-item"><span className="ref-num">[1]</span><span>Wu, H., Li, J., Zhao, K., et al. (2025). One-shot face sketch synthesis in the wild via generative diffusion prior and instruction tuning. arXiv.</span></div>
            <div className="ref-item"><span className="ref-num">[2]</span><span>Li, T., Tu, S., &amp; Xu, L. (2025). Text to sketch generation with multi-styles. arXiv.</span></div>
            <div className="ref-item"><span className="ref-num">[7]</span><span>Sun, B., Lu, G., &amp; Zheng, S. (2024). Multi-style facial sketch synthesis through masked generative modeling. arXiv.</span></div>
            <div className="ref-item"><span className="ref-num">[9]</span><span>Jang, W., Jung, Y., Kim, H., et al. (2024). Toonify3D: StyleGAN-based 3D stylized face generator. ACM SIGGRAPH Proceedings.</span></div>
            <div className="ref-item"><span className="ref-num">[11]</span><span>Gao, F., Zhu, Y., Jiang, C., &amp; Wang, N. (2023). Human-inspired facial sketch synthesis with dynamic adaptation. Proceedings of ICCV, 7203–7213.</span></div>
            <div className="ref-item"><span className="ref-num">[18]</span><span>Peng, Y., Zhao, C., Xie, H., Fukusato, T., &amp; Miyata, K. (2023). Sketch-guided latent diffusion model for high-fidelity face image synthesis. IEEE Access, 12, 5770–5780.</span></div>
            <div className="ref-item"><span className="ref-num">[19]</span><span>Fan, D., Huang, Z., Zheng, P., et al. (2022). Facial-sketch synthesis: A new challenge. Machine Intelligence Research, 19(4), 257–287.</span></div>
            <div className="ref-item"><span className="ref-num">[20]</span><span>Asimopoulos, D. C., Nitsiou, M., Lazaridis, L., &amp; Fragulis, G. F. (2022). Generative adversarial networks: A systematic review and applications. SHS Web of Conferences, 139, 03012.</span></div>
          </div>
        </div>
      </div>

      <footer>
        <div className="footer-inner">
          <div>
            <div className="footer-brand">PS-Style GAN</div>
            <div className="footer-sub">Facial Sketch Generator · SRM Institute of Science and Technology</div>
            <div className="footer-sub" style={{ marginTop: '8px' }}>Chennai, India · 2024</div>
            <div className="footer-designed">Designed by <span>Ajay Kumar Reddy K</span></div>
          </div>
          <div className="footer-links">
            <a href="https://github.com" target="_blank" rel="noreferrer">GitHub Repository →</a>
            <a href="#abstract">Read Abstract</a>
            <a href="#methodology">Methodology</a>
            <a href="#algorithm">Algorithm</a>
            <a href="#results">Results</a>
            <a href="#references">References</a>
          </div>
          <div>
            <div style={{ fontSize: '13px', color: 'rgba(255,255,255,0.5)', marginBottom: '12px' }}>Authors</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '13px', color: 'rgba(255,255,255,0.7)' }}>
              <span>Ajay Kumar Reddy K</span>
              <span>Sameer Raja E</span>
              <span>Jesheba Fedorah E</span>
              <span>Thanvarshini VR</span>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}
